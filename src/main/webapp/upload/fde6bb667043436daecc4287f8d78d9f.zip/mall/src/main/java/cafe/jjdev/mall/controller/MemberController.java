package cafe.jjdev.mall.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cafe.jjdev.mall.mapper.MemberMapper;
import cafe.jjdev.mall.service.MemberService;
import cafe.jjdev.mall.vo.Member;

@Controller
public class MemberController {
	//-------------------2019/05/08 개인 과제--------------------
	@Autowired private MemberService memberService;
	// 1 로그인 폼 
	@GetMapping(value="/member/login")
	public String login(HttpSession session) {
		if(session.getAttribute("loginMember") != null) {
			return "redirect:/";
		}else {
			return "/member/login";
		}
	}
	
	// 2 로그인 액션 MemberService.getMember(member) -> MemberMapper.selectMember(Member member)
	@PostMapping(value="/member/login") 
	public String login(HttpSession session, Member member) {
		Member loginMember = memberService.getMember(member); // 입력받은 아이디 비밀번호를 가지고 조건에 일치하는 list를 가져옴
		if(loginMember == null) {
			System.out.println("[cafe.jjdev.mall.controller.MemberController.getMember] POST 로그인 실패");
			return "redirect:/member/login";
		}else {
			// 마이페이지에서 내 정보 보기를 위해 pw까지 받아 올 것(로그인과 같은 쿼리를 사용할 것임)
			session.setAttribute("memberId", loginMember.getMemberId());
			session.setAttribute("memberPw", loginMember.getMemberPw());
			session.setAttribute("memberLevel", loginMember.getMemberLevel());
			
			System.out.println("[cafe.jjdev.mall.controller.MemberController.getMember] POST memberId: "+session.getAttribute("memberId"));
			System.out.println("[cafe.jjdev.mall.controller.MemberController.getMember] POST memberPw: "+session.getAttribute("memberPw"));
			System.out.println("[cafe.jjdev.mall.controller.MemberController.getMember] POST : "+session.getAttribute("memberLevel"));
			System.out.println("[cafe.jjdev.mall.controller.MemberController.getMember] POST 로그인 성공");
			return "redirect:/";
		}
	}
	
	// 3 로그아웃
	@GetMapping(value="/member/logout")
	public String logout(HttpSession session) {
		session.invalidate(); // 세션 무효화
		return "redirect:/";
	}
	
	// 4 회원 가입 폼  
	@GetMapping(value = "/member/addMember")
	public String addMember() {
		System.out.println("[cafe.jjdev.mall.controller.MemberController.addMember] GET addMember get방식 실행 확인------------");
		return "/member/addMember";
	}

	// 5 회원 가입 액션 MemberService.addMember(member) -> MemberMapper.insertMember(Member member)
	@PostMapping(value = "/member/addMember")
	public String addMember(Member member) {
		System.out.println("[cafe.jjdev.mall.controller.MemberController.addMember] POST member: "+member);
		memberService.addMember(member);
		return "redirect:/";
	}
	
	// 6 개인 정보 확인? MemberService.getMember(member) -> MemberMapper.selectMember(Member member)
	@GetMapping(value="/member/getMember")
	public String getMember(Model model, HttpSession session) {
		// 로그인중인 사람의 정보만 보게 할것
		Member member = new Member();
		member.setMemberId((String)session.getAttribute("memberId"));
		member.setMemberPw((String)session.getAttribute("memberPw"));
		model.addAttribute("member", memberService.getMember(member));
		System.out.println("[cafe.jjdev.mall.controller.MemberController.getMember] GET member: "+member);
		return "/member/getMember";
	}
	
	// 7 비밀번호만 수정 폼
	@GetMapping(value="/member/modifyMemberPw")
	public String modifyMemberPw(Model model, HttpSession session) {
		model.addAttribute("memberId", session.getAttribute("memberId"));
		System.out.println("[cafe.jjdev.mall.controller.MemberController.getMember] GET memberId: "+session.getAttribute("memberId"));
		return "/member/modifyMemberPw";
	}
	
	// 8 비밀번호 수정 액션 MemberService.ModifyMemberPw(member, currentMemberPw) -> MemberMapper.updateMemberPw(map)
	@PostMapping(value="/member/modifyMemberPw")
	public String modifyMemberPw(Member member, @RequestParam(value = "currentMemberPw") String currentMemberPw) {
		System.out.println("[cafe.jjdev.mall.controller.MemberController.modifyMemberPw] POST member: "+member);
		System.out.println("[cafe.jjdev.mall.controller.MemberController.modifyMemberPw] POST currentMemberPw: "+currentMemberPw);
		memberService.ModifyMemberPw(member, currentMemberPw);
		return "redirect:/";
	}
	// 9 비밀번호 제외 수정 폼
	@GetMapping(value = "/member/modifyMemberExceptPw")
	public String modifyMemberExceptPw(Model model, HttpSession session) {
		// 로그인중인 사람의 정보만 보게 할것
		Member member = new Member();
		member.setMemberId((String)session.getAttribute("memberId"));
		member.setMemberPw((String)session.getAttribute("memberPw"));
		model.addAttribute("member", memberService.getMember(member));	
		return "/member/modifyMemberExceptPw";
	}
	// 10 비밀번호 제외 수정 액션 MemberService.modifyMember(member) -> MemberMapper.updateMember(member)
	@PostMapping(value = "/member/modifyMemberExceptPw")
	public String modifyMemberExceptPw(Member member) {
		System.out.println("[cafe.jjdev.mall.controller.MemberController.modifyMemberExceptPw] POST member: "+member);		
		memberService.modifyMember(member);
		return "redirect:/";
	}
	
	// 11 회원 탈퇴 폼
	@GetMapping(value = "/member/removeMember")
	public String removeMember() {
		return "/member/removeMember";
	}
	// 12 회원 탈퇴 액션.. 회원 탈퇴 시 id를 재사용 불가능하게 어딘가에 보관해야 한다.
	// MemberService.removeMember(member) -> DeletedMemberRepository.storetheMemberId(member) AND MemberMapper.deleteMember(member)
	@PostMapping(value = "/member/removeMember")
	public String removeMember(Member member, HttpSession session) {
		System.out.println("[cafe.jjdev.mall.controller.MemberController.removeMember] POST member: "+member);		
		session.invalidate(); // 회원 탈퇴 전 로그아웃	
		memberService.removeMember(member);
		return "redirect:/";
	}
	
	//-------------------2019/05/08까지 제출--------------------
	//-------------------2019/05/09 팀 과제--------------------
	// 13 아이디 찾기
	
	// 14 비밀번호 찾기
	
	// 15 member_out_id 테이블을 만들어서 회원 탈퇴한 id를 저장
}
