package cafe.jjdev.mall.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cafe.jjdev.mall.mapper.DeletedMemberRepository;
import cafe.jjdev.mall.mapper.MemberMapper;
import cafe.jjdev.mall.vo.Member;

@Service
public class MemberService {
	@Autowired private MemberMapper memberMapper;
	@Autowired private DeletedMemberRepository deletedMemberRepository;
	
	// 회원 가입
	public void addMember(Member member) {
		String id = deletedMemberRepository.selectMemberId(member);
		if(id == null) {
			memberMapper.insertMember(member);
			System.out.println("[cafe.jjdev.mall.service.MemberService.addMember] 이미 있는 아이디이다.");
		}
	}
	
	// 회원 한명 조회
	public Member getMember(Member member) {
		return memberMapper.selectMember(member);
	}
	
	// 비밀번호만 수정
	public void ModifyMemberPw(Member member, String currentMemberPw) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("memberId", member.getMemberId());
		map.put("memberPw", member.getMemberPw());
		map.put("currentMemberPw", currentMemberPw);
		memberMapper.updateMemberPw(map);
	}
	
	// 비밀번호를 제외한 회원 수정
	public void modifyMember(Member member) {
		memberMapper.updateMember(member);
	}
	
	// 회원 탈퇴
	public void removeMember(Member member) {
		// 삭제 하기 전 member를 다른 테이블에 저장한다.
		deletedMemberRepository.storetheMemberId(member);
		// 회원 정보를 삭제한다.
		memberMapper.deleteMember(member);
	}
}
