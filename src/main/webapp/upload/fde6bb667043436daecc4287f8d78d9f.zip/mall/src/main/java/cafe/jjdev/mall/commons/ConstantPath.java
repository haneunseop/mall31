package cafe.jjdev.mall.commons;

public class ConstantPath {
	public static final String UPLOAD_PATH = "D:/haneunseop/jjdev/sts-workspace/mall/src/main/webapp/upload/";
}
